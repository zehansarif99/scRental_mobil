<footer class="sticky-footer bg-white">
	<div class="container my-auto">
	    <div class="copyright text-center my-auto">
	    <span>
	    <a href="https://instagram.com/zehansyarif" target="_blank">Muhammad Zehan Sarif</a> &copy; Aplikasi Rental Mobil <?= date('D, d-M-Y') ?></span>
	    </div>
	</div>
</footer>