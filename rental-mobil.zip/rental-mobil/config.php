<?php 

if(!defined('BASEPATH')) echo "Tidak bisa langsung mengakses halaman ini!";

define('DEFAULT_CONTROLLER', 'C_Auth');
define('BASE_URL', 'http://localhost/rental-mobil/');
define('APP_NAME', 'Aplikasi Rental Mobil');

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'rental_mobil');

?>